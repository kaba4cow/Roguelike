version 0.1.8

CONTROLS :

W A S D - movement keys

C - unlock / lock the camera

G - hide / show player�s gui

Mouse Wheel - search through player�s inventory

Right Mouse Button � toggle selection cursor

Left Mouse Button - place tiles / shoot

P - take a screenshot

Escape - pause