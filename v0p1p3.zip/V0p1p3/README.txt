version 0.1.3

CONTROLS :

W A S D - movement keys

I - hide / show player's GUI

Escape - pause

Right Mouse Button - toggle selection cursor

Mouse Wheel - zoom