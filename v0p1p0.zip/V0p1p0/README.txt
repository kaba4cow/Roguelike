version 0.1

CONTROLS :

W A S D - movement keys

Enter - new game