version 0.1.5

CONTROLS :

W A S D - movement keys

C - unlock / lock the camera

G - hide / show player�s gui

Mouse Wheel - zoom

Right Mouse Button � toggle selection cursor

Left Mouse Button - place tiles / shoot

P - take a screenshot

Space - hit

Escape - pause