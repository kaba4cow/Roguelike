version 0.1.4

CONTROLS :

W A S D - movement keys

C - unlock / lock the camera

G - hide / show player�s gui

Mouse Wheel - zoom

Right Mouse Button � toggle selection cursor

Escape - pause